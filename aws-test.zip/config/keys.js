module.exports = {
    iterableUrl: 'https://api.iterable.com/api/'
}